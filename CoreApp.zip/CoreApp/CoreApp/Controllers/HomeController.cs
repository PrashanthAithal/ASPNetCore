﻿using CoreApp.Models;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;

namespace CoreApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductRepository _productRepository;

        public HomeController(IProductRepository productRepository) {
            _productRepository= productRepository;
        }
        public List<Product> Index()
        {
            //HttpContext.Session.SetString("ProductId", "3");

            //throw new FileNotFoundException("File not found exception thrown in index.chtml");
           
            return _productRepository.GetAll();
        }
    }
}
