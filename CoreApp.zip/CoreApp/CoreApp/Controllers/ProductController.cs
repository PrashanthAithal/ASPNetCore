﻿using CoreApp.Models;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;

namespace CoreApp.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;

        public ProductController(IProductRepository productRepository) {
            _productRepository= productRepository;
        }
        [Route("Products/All")]
        public Product Index()
        {
            int productId = Convert.ToInt16(HttpContext.Session.GetString("ProductId"));
            return _productRepository.Get(3);
        }
    }
}
