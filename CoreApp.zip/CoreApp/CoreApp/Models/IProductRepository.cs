﻿namespace CoreApp.Models
{
    public interface IProductRepository
    {
        void Add(Product product);
        Product Get(int id);

        List<Product> GetAll();
    }
}
