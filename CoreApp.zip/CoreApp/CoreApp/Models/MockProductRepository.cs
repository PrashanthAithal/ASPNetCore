﻿
namespace CoreApp.Models
{
    public class MockProductRepository : IProductRepository
    {
        private List<Product> _productList;   

        public MockProductRepository()
        {
            _productList = new List<Product>() {
            new Product(){ProductId=1, ProductCategory="Grocery", ProductName="P1", ProductDescription="PRD1"},
            new Product(){ProductId=2, ProductCategory="Grocery", ProductName="P2", ProductDescription="PRD2"},
            new Product(){ProductId=3, ProductCategory="Grocery", ProductName="P3",ProductDescription="PRD3"},
            };
        }
        void IProductRepository.Add(Product product)
        {
            throw new NotImplementedException();
        }

        Product IProductRepository.Get(int id)
        {
            return _productList.FirstOrDefault(a => a.ProductId == id);
        }

        List<Product> IProductRepository.GetAll()
        {
            return _productList.ToList();
        }
    }
}
