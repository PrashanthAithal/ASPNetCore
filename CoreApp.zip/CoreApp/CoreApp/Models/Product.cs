﻿namespace CoreApp.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public required string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public required string ProductCategory { get; set; }
        public int ProductCategoryId { get; set; }
    }
}
